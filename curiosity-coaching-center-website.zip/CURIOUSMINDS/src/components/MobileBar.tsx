import { useEffect, useState } from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import { messages, phoneLink, whatsappLink } from '../lib/links';

/**
 * On phones, keeps WhatsApp and Call one tap away once the top buttons have
 * scrolled out of view.
 */
export function MobileBar() {
  const [shown, setShown] = useState(false);
  const tel = phoneLink();

  useEffect(() => {
    const target = document.getElementById('hero-actions');
    if (!target || !('IntersectionObserver' in window)) {
      setShown(true);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => {
      setShown(!entry.isIntersecting && entry.boundingClientRect.top < 0);
    });
    observer.observe(target);
    return () => observer.disconnect();
  }, []);

  return (
    <div className={`mobile-bar${shown ? ' is-shown' : ''}`}>
      <a className="btn btn-wa" href={whatsappLink(messages.general)} target="_blank" rel="noopener">
        <MessageCircle className="btn-icon" aria-hidden="true" />
        WhatsApp करें
      </a>
      {tel && (
        <a className="btn btn-line" href={tel}>
          <Phone className="btn-icon" aria-hidden="true" />
          कॉल करें
        </a>
      )}
    </div>
  );
}
