import { StrictMode } from 'react';
import { createRoot, hydrateRoot } from 'react-dom/client';
import '@fontsource/mukta/400.css';
import '@fontsource/mukta/700.css';
import '@fontsource/kalam/700.css';
import './index.css';
import App from './App';

const container = document.getElementById('root')!;
const app = (
  <StrictMode>
    <App />
  </StrictMode>
);

// The production build ships the page already rendered (see scripts/prerender.mjs),
// so React only attaches to it. In `npm run dev` the page is rendered here instead.
if (container.firstElementChild) {
  hydrateRoot(container, app);
} else {
  createRoot(container).render(app);
}
