import { MessageCircle } from 'lucide-react';
import { messages, whatsappLink } from '../lib/links';
import { Logo } from './Logo';

const NAV = [
  { href: '#teaching', label: 'पढ़ाई का तरीक़ा' },
  { href: '#batches', label: 'बैच' },
  { href: '#fees', label: 'फ़ीस' },
  { href: '#level-check', label: 'लेवल चेक' },
  { href: '#policy', label: 'पॉलिसी' },
  { href: '#location', label: 'पता' },
];

export function Header() {
  return (
    <header className="site-header">
      <div className="header-inner">
        <Logo />
        <nav aria-label="इस पेज पर" className="header-nav">
          <ul>
            {NAV.map((item) => (
              <li key={item.href}>
                <a href={item.href}>{item.label}</a>
              </li>
            ))}
          </ul>
        </nav>
        <a className="btn btn-wa btn-small" href={whatsappLink(messages.general)} target="_blank" rel="noopener">
          <MessageCircle className="btn-icon" aria-hidden="true" />
          WhatsApp करें
        </a>
      </div>
    </header>
  );
}
