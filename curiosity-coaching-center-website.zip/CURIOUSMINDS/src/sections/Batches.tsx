import { Section } from '../components/Section';
import { batches, maxBatchSize, testSeries } from '../content/site';
import { messages, whatsappLink } from '../lib/links';

export function Batches() {
  return (
    <Section id="batches" en="Batches and timings" hi="बैच और समय">
      <p className="lead">
        क्लास सोमवार से शनिवार चलती हैं, छोटे बैच में
        {maxBatchSize ? `, हर बैच में ज़्यादा से ज़्यादा ${maxBatchSize} बच्चे` : ''}।
      </p>

      <ul className="timetable">
        {batches.map((batch) => (
          <li key={batch.id} className="timetable-row">
            <h3 className="timetable-class">
              {batch.name}
              <span className="timetable-en" lang="en">
                {batch.english}
              </span>
            </h3>
            <div className="timetable-detail">
              <p>
                {batch.subjects ? `${batch.subjects}। ` : ''}
                {batch.detail}
              </p>
              <p className="timetable-time">
                <span>समय:</span>{' '}
                {batch.time ? (
                  batch.time
                ) : (
                  <a href={whatsappLink(messages.timings)} target="_blank" rel="noopener">
                    WhatsApp पर पूछें
                  </a>
                )}
              </p>
            </div>
          </li>
        ))}
        {testSeries.show && (
          <li className="timetable-row">
            <h3 className="timetable-class">
              {testSeries.name}
              <span className="timetable-en" lang="en">
                {testSeries.english}
              </span>
            </h3>
            <div className="timetable-detail">
              <p>{testSeries.detail}</p>
              <p className="timetable-time">
                <span>कब:</span> {testSeries.when}, हर हफ़्ते
              </p>
            </div>
          </li>
        )}
      </ul>

      <p>बच्चे के स्कूल की शिफ़्ट बताइए, हम उसी हिसाब से बैच सुझाएँगे।</p>
      <p className="aside">
        दोपहर की शिफ़्ट वाले स्कूल के बच्चे सुबह ख़ाली रहते हैं, इसलिए हम उनके लिए सुबह का बैच शुरू करने की सोच रहे
        हैं।{' '}
        <a href={whatsappLink(messages.morningBatch)} target="_blank" rel="noopener">
          सुबह के बैच में रुचि बताएँ
        </a>
      </p>
    </Section>
  );
}
