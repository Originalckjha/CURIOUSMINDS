import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: '/',
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
  ssr: {
    // bundled into the build-time renderer so it runs without extra setup
    noExternal: ['lucide-react'],
  },
  server: {
    port: 3000,
  },
});
