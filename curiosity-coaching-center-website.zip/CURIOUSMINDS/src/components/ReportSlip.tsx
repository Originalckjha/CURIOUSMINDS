import { Monogram } from './Logo';
import { Ring } from './RedPen';

/**
 * A sample of the one-page monthly report. Every name and number on it is
 * made up, and the slip says so twice: the stamp and the caption.
 */
export function ReportSlip() {
  return (
    <figure className="slip-wrap">
      <div className="slip">
        <div className="slip-head">
          <Monogram className="slip-mark" />
          <div>
            <p className="slip-title">मासिक रिपोर्ट</p>
            <p className="slip-sub" lang="en">
              Monthly report
            </p>
          </div>
        </div>

        <p className="slip-stamp" aria-label="यह नमूना रिपोर्ट है">
          <span aria-hidden="true">नमूना</span>
          <span aria-hidden="true" lang="en">
            Sample
          </span>
        </p>

        <dl className="slip-meta">
          <div>
            <dt>नाम</dt>
            <dd>नमूना छात्र</dd>
          </div>
          <div>
            <dt>कक्षा</dt>
            <dd>6</dd>
          </div>
          <div>
            <dt>महीना</dt>
            <dd>नवंबर</dd>
          </div>
        </dl>

        <table className="slip-table">
          <thead>
            <tr>
              <td />
              <th scope="col">इस महीने</th>
              <th scope="col">पिछले महीने</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">उपस्थिति</th>
              <td>23/25</td>
              <td>21/24</td>
            </tr>
            <tr>
              <th scope="row">होमवर्क पूरा</th>
              <td>21/24</td>
              <td>16/24</td>
            </tr>
            <tr>
              <th scope="row">मैथ्स टेस्ट</th>
              <td>
                <span className="slip-ringed">
                  17/25
                  <Ring className="slip-ring" draw />
                  <span className="slip-plus" lang="en">
                    +6
                  </span>
                </span>
              </td>
              <td>11/25</td>
            </tr>
            <tr>
              <th scope="row">इंग्लिश टेस्ट</th>
              <td>14/20</td>
              <td>12/20</td>
            </tr>
          </tbody>
        </table>

        <dl className="slip-notes">
          <div>
            <dt>अच्छी बात</dt>
            <dd>भिन्न (fractions) के सवाल अब ज़्यादातर सही।</dd>
          </div>
          <div>
            <dt>इस महीने ध्यान</dt>
            <dd>12 से 15 तक के पहाड़े, रोज़ 10 मिनट।</dd>
          </div>
        </dl>

        <p className="slip-pen" lang="en">
          Good progress. Keep it up!
        </p>
        <p className="slip-foot">पढ़कर WhatsApp पर “seen” लिख दीजिए।</p>
      </div>
      <figcaption className="slip-caption">
        हर बच्चे की ऐसी एक पन्ने की रिपोर्ट हर महीने WhatsApp पर आती है। ऊपर का नाम और नंबर सिर्फ़ नमूना हैं।
      </figcaption>
    </figure>
  );
}
