/** ₹ amount with Indian digit grouping, e.g. 1400 -> "₹1,400", 125000 -> "₹1,25,000". */
export function formatRupees(amount: number): string {
  const [whole, fraction] = String(Math.round(amount * 100) / 100).split('.');
  const lastThree = whole.slice(-3);
  const rest = whole.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  const grouped = rest ? `${rest},${lastThree}` : lastThree;
  return `₹${grouped}${fraction ? `.${fraction}` : ''}`;
}
