import { Section } from '../components/Section';
import { batches, testSeries, type Rupees } from '../content/site';
import { formatRupees } from '../lib/format';
import { messages, openCourses, whatsappLink } from '../lib/links';

const INCLUDED = [
  'सोमवार से शनिवार रोज़ क्लास',
  'रोज़ होमवर्क चेक',
  'हर महीने टेस्ट और लिखित रिपोर्ट',
  'हर टर्म पेरेंट मीटिंग',
];

function Price({ amount }: { amount: Rupees }) {
  if (amount === null) {
    return (
      <a href={whatsappLink(messages.fees)} target="_blank" rel="noopener">
        WhatsApp पर पूछें
      </a>
    );
  }
  return (
    <span>
      <strong>{formatRupees(amount)}</strong> महीना
    </span>
  );
}

export function Fees() {
  const courseFeesApply = openCourses().length > 0;
  return (
    <Section id="fees" en="Fees" hi="फ़ीस">
      <dl className="price-list">
        {batches.map((batch) => (
          <div key={batch.id} className="price-row">
            <dt>{batch.name}</dt>
            <dd>
              <Price amount={batch.fee} />
            </dd>
          </div>
        ))}
        {testSeries.show && (
          <div className="price-row">
            <dt>सिर्फ़ कक्षा 10 टेस्ट सीरीज़</dt>
            <dd>
              <Price amount={testSeries.feePerMonth} />
            </dd>
          </div>
        )}
      </dl>

      <h3 className="minor-title">फ़ीस में शामिल</h3>
      <ul className="plain-list">
        {INCLUDED.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>

      <h3 className="minor-title">फ़ीस कैसे दें</h3>
      <p>
        हर महीने 10 तारीख़ तक, पहले से। UPI या नकद, हमेशा रसीद के साथ। फ़ीस में बदलाव एक महीना पहले बताया जाता है
        और अप्रैल से लागू होता है।
      </p>
      {courseFeesApply && (
        <p>
          कोर्स की फ़ीस एक साथ या दो किस्तों में। कोर्स हम रद्द करें या आप बीच में छोड़ें, तो बचे हुए सेशन का पैसा 10
          दिन में लौटा देते हैं।
        </p>
      )}

      <p className="aside">
        दाख़िले से पहले <a href="#level-check">मुफ़्त लेवल चेक</a> और दो दिन की ट्रायल क्लास कीजिए, उसके बाद तय
        कीजिए।
      </p>
    </Section>
  );
}
