import { site } from '../content/site';

/** The three-C monogram from public/logo.svg, cropped to the mark itself. */
const MONOGRAM_PATHS = [
  'M985.58,222.72 A539.42,539.42 0 1 0 985.58,985.58 L924.24,924.24 A452.68,452.68 0 1 1 924.24,284.06 Z',
  'M324.14,890.05 A404.45,404.45 0 1 0 324.14,318.07 L379.73,373.66 A325.83,325.83 0 1 1 379.73,834.46 Z',
  'M793.21,413.59 A270.20,270.20 0 1 0 793.21,795.71 L729.03,731.53 A179.43,179.43 0 1 1 729.03,477.77 Z',
];

export function Monogram({ className = '', label }: { className?: string; label?: string }) {
  return (
    <svg
      viewBox="64.73 64.73 949.85 1078.84"
      className={className}
      fill="currentColor"
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      focusable="false"
    >
      {MONOGRAM_PATHS.map((d) => (
        <path key={d} d={d} />
      ))}
    </svg>
  );
}

export function Logo() {
  return (
    <a href="#top" className="logo" aria-label={`${site.name}, पेज के ऊपर जाएँ`}>
      <Monogram className="logo-mark" />
      <span className="logo-words" lang="en">
        <span className="logo-name">Curiosity</span>
        <span className="logo-rest">Coaching Center</span>
      </span>
    </a>
  );
}
