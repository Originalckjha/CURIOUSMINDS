import { Star } from 'lucide-react';
import { Section } from '../components/Section';
import { reviewsLink } from '../lib/links';

export function Reviews() {
  return (
    <Section id="reviews" en="Reviews" hi="माता-पिता की राय">
      <p className="lead">
        हम यहाँ अपनी पसंद की तारीफ़ें नहीं छापते। माता-पिता ने Google पर जो लिखा है, पूरा वहीं पढ़िए।
      </p>
      <a className="btn btn-line" href={reviewsLink()} target="_blank" rel="noopener">
        <Star className="btn-icon" aria-hidden="true" />
        Google पर रिव्यू पढ़ें
      </a>
    </Section>
  );
}
