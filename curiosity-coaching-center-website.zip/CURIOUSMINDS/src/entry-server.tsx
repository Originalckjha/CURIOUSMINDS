import { StrictMode } from 'react';
import { renderToString } from 'react-dom/server';
import App from './App';
import { batches, levelCheck, site, teachers } from './content/site';
import { missingContactDetails, phoneLink } from './lib/links';

/** Used at build time by scripts/prerender.mjs. */

export function render(): string {
  return renderToString(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

const DESCRIPTION =
  'मंगोलपुरी, दिल्ली में कक्षा 1–10 की ट्यूशन। छोटे बैच, रोज़ होमवर्क चेक, हर महीने टेस्ट और माता-पिता को लिखित रिपोर्ट। नए बच्चों के लिए मुफ़्त लेवल चेक।';

const SHARE_TITLE = 'Curiosity Coaching Center, मंगोलपुरी';
const SHARE_DESCRIPTION = 'हर महीने टेस्ट, हर महीने रिपोर्ट। कक्षा 1–10, छोटे बैच, रोज़ होमवर्क चेक।';

const attr = (value: string) =>
  value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function structuredData(origin: string) {
  const tel = phoneLink().replace('tel:', '');
  const data: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': ['EducationalOrganization', 'LocalBusiness'],
    name: site.name,
    slogan: site.slogan.en,
    description:
      'Tuition for Classes 1 to 10 in Mangolpuri, New Delhi. Small batches, homework checked daily, a test and a written progress report for parents every month.',
    areaServed: site.area.en,
    address: {
      '@type': 'PostalAddress',
      ...(site.address.streetEnglish ? { streetAddress: site.address.streetEnglish } : {}),
      addressLocality: 'Mangolpuri',
      addressRegion: 'Delhi',
      ...(site.address.pincode ? { postalCode: site.address.pincode } : {}),
      addressCountry: 'IN',
    },
  };
  if (tel) data.telephone = tel;
  if (origin) {
    data.url = `${origin}/`;
    data.logo = `${origin}/icon-512.png`;
    data.image = `${origin}/og-image.png`;
  }
  const sameAs = [site.instagramUrl, site.mapsUrl].filter(Boolean);
  if (sameAs.length) data.sameAs = sameAs;
  // "<" is escaped so the JSON can never close the script tag early.
  return JSON.stringify(data).replace(/</g, '\\u003c');
}

/** Meta tags, link-preview tags and structured data for <head>. */
export function head(origin: string): string {
  const tags = [
    `<meta name="description" content="${attr(DESCRIPTION)}" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:locale" content="hi_IN" />`,
    `<meta property="og:site_name" content="${attr(site.name)}" />`,
    `<meta property="og:title" content="${attr(SHARE_TITLE)}" />`,
    `<meta property="og:description" content="${attr(SHARE_DESCRIPTION)}" />`,
  ];
  if (origin) {
    tags.push(
      `<link rel="canonical" href="${origin}/" />`,
      `<meta property="og:url" content="${origin}/" />`,
      `<meta property="og:image" content="${origin}/og-image.png" />`,
      `<meta property="og:image:width" content="1200" />`,
      `<meta property="og:image:height" content="630" />`,
      `<meta property="og:image:alt" content="${attr(`${site.name}: हर महीने टेस्ट, हर महीने रिपोर्ट`)}" />`,
      `<meta name="twitter:card" content="summary_large_image" />`,
    );
  }
  tags.push(`<script type="application/ld+json">${structuredData(origin)}</script>`);
  if (site.cloudflareAnalyticsToken) {
    tags.push(
      `<script defer src="https://static.cloudflareinsights.com/beacon.min.js" data-cf-beacon='{"token": "${attr(
        site.cloudflareAnalyticsToken,
      )}"}'></script>`,
    );
  }
  return tags.join('\n    ');
}

/** Everything in src/content/site.ts that is still empty, for the build log. */
export function setupReport(origin: string): string[] {
  const todo = [...missingContactDetails()];
  if (!site.reviewsUrl) todo.push('Google reviews link');
  if (!site.hours) todo.push('opening hours');
  if (!site.replyHours) todo.push('WhatsApp reply hours');
  if (!site.address.streetEnglish) todo.push('street address in English (for Google)');
  if (!site.address.pincode) todo.push('PIN code');
  for (const batch of batches) {
    if (!batch.time) todo.push(`time for ${batch.english}`);
    if (batch.fee === null) todo.push(`fee for ${batch.english}`);
  }
  if (!levelCheck.saturdayTime) todo.push('level check time on Saturdays');
  if (teachers.length === 0) todo.push('teachers (names, subjects, qualifications)');
  if (!origin) todo.push('site address (siteUrl), needed for link previews on WhatsApp');
  return todo;
}

export { site };
