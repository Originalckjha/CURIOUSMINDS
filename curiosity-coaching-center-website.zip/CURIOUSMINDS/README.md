# Curiosity Coaching Center website

One fast page for Curiosity Coaching Center, Mangolpuri, built to the website outline in the growth plan: Hindi first with English headings, WhatsApp as the admissions desk, and light enough for a budget phone on mobile data (about 350 KB in all).

Sections, in order: top with WhatsApp, Call and Directions buttons · how we teach, with a sample monthly report · batches and timings · fees · teachers · free level check, with a booking form · new courses (hidden until registration opens) · parent policy · Google reviews · location · privacy note.

## Before it goes live

Fill the values marked `TODO` in **`src/content/site.ts`**:

- WhatsApp number, phone number, address with landmark, PIN code, Google Maps link
- Google reviews link, opening hours, WhatsApp reply hours
- batch times and monthly fees for Classes 1–5, 6–8 and 9–10
- Saturday time for the free level check
- both teachers: name, what they teach, qualifications, experience (photo optional)

Nothing empty is ever shown as a blank: the page hides that line or says "WhatsApp पर पूछें". Until the WhatsApp number, phone, address and Maps link are filled, a yellow **Not ready to go live** note shows at the top of the page. `npm run build` prints everything still empty.

## Changing content

Everything that changes from season to season is in `src/content/site.ts`: contact details, batches, fees, the Class 10 test series, teachers, the parent policy, and the two new courses. Set a course's `open: true` when its registration opens and it appears on the page, in the booking options and in the parent policy's course-fee rule.

Other wording lives in `src/sections/*.tsx` (one file per section) and `src/components/Hero.tsx`.

## WhatsApp enquiries

Every WhatsApp button types a message ending in **(WEB)**, so an enquiry from the website can be logged with source **Website** in the tracker. The level-check form also fills in the child's class, school shift, parent's name and who referred them.

## Running it

```bash
npm install
npm run dev       # http://localhost:3000
npm run build     # builds and prerenders the page into dist/
npm run preview   # serves dist/
```

The build renders the page to plain HTML (`scripts/prerender.mjs`), so it appears instantly and Google reads all of it; React then attaches for the booking form and the phone action bar.

## Deploying

On Vercel: import the repository, keep the Vite defaults (build `npm run build`, output `dist`). The production address is picked up automatically for link previews; set `siteUrl` in `site.ts` (or a `SITE_URL` environment variable) once you have your own domain. Old addresses from the previous site (`/about`, `/contact`, `/login` and so on) redirect to the matching part of the page.

Go-live checklist from the plan:

- Register the `.in` domain in your own name and account, and point it at the hosting.
- Put the website link in the Google Business Profile and the Instagram bio.
- Verify the site in Google Search Console.
- Optional: add a free Cloudflare Web Analytics token in `site.ts` for a cookie-free visitor count.

## Design

A notebook page: ink on paper, a red margin line, headline written on ruled lines. Red is kept for two things only: the logo and the teacher's red pen (ticks, the ringed score, the sample stamp). Fonts are Mukta (Hindi and English) and Kalam (handwriting), self-hosted. `public/logo.svg` is the original logo file; the favicon, home-screen icons and `og-image.png` (the WhatsApp link preview) are made from it.
