import { Section } from '../components/Section';
import { Tick } from '../components/RedPen';

const SYSTEM = [
  {
    title: 'स्कूल का होमवर्क रोज़ पूरा और चेक',
    text: 'अधूरा होमवर्क घर जाने से पहले यहीं पूरा होता है। हफ़्ते में तीन बार छूटे तो हम आपको बताते हैं।',
  },
  {
    title: 'हर महीने टेस्ट',
    text: 'महीने के पहले हफ़्ते में टेस्ट और तीन दिन में नतीजा। उस दिन जो बच्चा नहीं आया, उसका टेस्ट उसी हफ़्ते दोबारा होता है।',
  },
  {
    title: 'हर महीने लिखित रिपोर्ट',
    text: 'एक पन्ने की रिपोर्ट WhatsApp पर: उपस्थिति, होमवर्क, इस महीने और पिछले महीने के नंबर, एक अच्छी बात और आगे किस पर ध्यान देना है।',
  },
  {
    title: 'हर टर्म पेरेंट मीटिंग',
    text: 'दिसंबर, मार्च और जुलाई में, बच्चे की टेस्ट फ़ाइल सामने रखकर।',
  },
];

const WALL_RULES = ['समय पर आना', 'फ़ोन बास्केट में', 'पहले होमवर्क', 'सबकी इज़्ज़त', 'अटको तो पूछो'];

export function Teaching() {
  return (
    <Section id="teaching" en="How we teach" hi="सख़्ती नहीं, सिस्टम">
      <p className="lead">
        हम रूटीन में सख़्त हैं, बच्चों के साथ कठोर नहीं। बढ़-चढ़कर वादे करने के बजाय हर महीने टेस्ट लेकर दिखाते हैं
        कि बच्चा कहाँ से कहाँ पहुँचा।
      </p>

      <ul className="checklist">
        {SYSTEM.map((item) => (
          <li key={item.title}>
            <Tick className="checklist-tick" />
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </li>
        ))}
      </ul>

      <div className="wall">
        <h3 className="wall-title">दीवार पर लिखे पाँच नियम</h3>
        <ul className="wall-rules">
          {WALL_RULES.map((rule) => (
            <li key={rule}>{rule}</li>
          ))}
        </ul>
        <p className="wall-note">
          ग़लती अकेले में सुधारते हैं, तारीफ़ सबके सामने करते हैं। शारीरिक सज़ा या अपमान कभी नहीं।
        </p>
      </div>

      <p className="aside">पहले महीने में आप किसी भी दिन 15 मिनट क्लास में पीछे बैठकर देख सकते हैं।</p>
    </Section>
  );
}
