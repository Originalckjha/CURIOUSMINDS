/*
 * Curiosity Coaching Center: website content
 * ------------------------------------------------------------------
 * Everything on the page that you might want to change lives in this
 * one file. Fill the values marked TODO before the site goes live.
 *
 * An empty value ('' or null) is never shown as a blank: the page
 * either hides that line or tells parents to ask on WhatsApp. A note at
 * the top of the page lists the contact details still missing, and it
 * disappears once WhatsApp number, phone and address are filled in.
 */

export type Rupees = number | null;

export const site = {
  name: 'Curiosity Coaching Center',
  slogan: {
    en: 'Curious minds. Disciplined habits.',
    hi: 'जिज्ञासा से सीखें, अनुशासन से आगे बढ़ें।',
  },
  area: { hi: 'मंगोलपुरी, नई दिल्ली', en: 'Mangolpuri, New Delhi' },

  /** TODO WhatsApp Business number with country code, digits only, e.g. '919812345678'. */
  whatsapp: '',
  /** TODO Number for the Call button, written as you want it shown, e.g. '+91 98123 45678'. */
  phone: '',

  address: {
    /** TODO House number and block, as parents would write it, e.g. 'मकान नं. 12, R ब्लॉक'. */
    line: '',
    /** TODO A landmark everyone knows, written to follow the line, e.g. 'सरकारी स्कूल के पास'. */
    landmark: '',
    /** TODO PIN code, e.g. '110083'. */
    pincode: '',
    /** TODO The street address in English, exactly as on your Google profile, e.g. 'H. No. 12, R Block'. Google reads this one. */
    streetEnglish: '',
  },

  /** TODO "Share" link of your Google Maps listing, e.g. 'https://maps.app.goo.gl/...'. */
  mapsUrl: '',
  /** TODO Link to your Google reviews (Google profile, "Read reviews"). */
  reviewsUrl: '',
  /** Instagram profile link, once the account exists. */
  instagramUrl: '',

  /** TODO Days and hours the centre is open, e.g. 'सोमवार से शनिवार, दोपहर 2 से शाम 8 बजे'. */
  hours: '',
  /** TODO When you answer WhatsApp, e.g. 'सुबह 10 से रात 8 बजे'. Used in the parent policy. */
  replyHours: '',

  /**
   * Your web address once you have one, e.g. 'https://curiositycoachingcenter.in'.
   * Leave empty on Vercel and the project's own address is used automatically.
   */
  siteUrl: '',

  /** Optional: a free Cloudflare Web Analytics token for a cookie-free visitor count. */
  cloudflareAnalyticsToken: '',
};

/* ---------------------------------------------------------------- */
/* Batches and fees                                                  */
/* ---------------------------------------------------------------- */

export interface Batch {
  id: string;
  name: string;
  english: string;
  /** Subjects taught. Leave '' to hide. */
  subjects: string;
  detail: string;
  /** TODO Batch time, e.g. 'शाम 4 से 5:30 बजे'. */
  time: string;
  /** TODO Monthly fee in rupees, e.g. 900. */
  fee: Rupees;
}

export const batches: Batch[] = [
  {
    id: 'classes-1-5',
    name: 'कक्षा 1–5',
    english: 'Classes 1–5',
    subjects: 'सभी विषय',
    detail: 'स्कूल का होमवर्क रोज़ पूरा और चेक, हर महीने टेस्ट और रिपोर्ट।',
    time: '',
    fee: null,
  },
  {
    id: 'classes-6-8',
    name: 'कक्षा 6–8',
    english: 'Classes 6–8',
    subjects: '',
    detail: 'रोज़ अभ्यास, हर महीने टेस्ट, हर ग़लती पर काम।',
    time: '',
    fee: null,
  },
  {
    id: 'classes-9-10',
    name: 'कक्षा 9–10',
    english: 'Classes 9–10',
    subjects: '',
    detail: 'CBSE बोर्ड की तैयारी: रोज़ अभ्यास, हर महीने टेस्ट और ग़लतियों पर काम।',
    time: '',
    fee: null,
  },
];

/** Most children in one batch. Shown only when set; put your real limit, e.g. 15. */
export const maxBatchSize: number | null = null;

export const testSeries = {
  show: true,
  name: 'कक्षा 10 बोर्ड टेस्ट सीरीज़',
  english: 'Class 10 board test series',
  when: 'दिसंबर से फ़रवरी',
  detail:
    'CBSE पैटर्न पर हर हफ़्ते टेस्ट पेपर, जाँच और हर ग़लती पर काम। दूसरी ट्यूशन में पढ़ने वाले बच्चे भी आ सकते हैं।',
  /** Monthly fee for the test series on its own. */
  feePerMonth: 400 as Rupees,
};

/* ---------------------------------------------------------------- */
/* Free level check                                                  */
/* ---------------------------------------------------------------- */

export const levelCheck = {
  /** TODO Saturday time, e.g. 'सुबह 11 बजे'. Shown as "हर शनिवार सुबह 11 बजे, या किसी बैच से पहले।" */
  saturdayTime: '',
};

/* ---------------------------------------------------------------- */
/* Teachers                                                          */
/* ---------------------------------------------------------------- */

export interface Teacher {
  name: string;
  /** Classes and subjects, e.g. 'कक्षा 1–8, गणित और विज्ञान'. */
  teaches: string;
  /** e.g. 'BCA'. */
  qualification: string;
  /** e.g. 'लगभग 7 साल'. */
  experience: string;
  /** Optional photo: put a small JPG (about 100 KB) in public/teachers/ and write '/teachers/name.jpg'. */
  photo?: string;
}

/** TODO Add both of you. Until this list has names, the page shows one line about the team instead. */
export const teachers: Teacher[] = [];

export const teamLine =
  'Curiosity Coaching Center दो भाई-बहन मिलकर चलाते हैं, जिन्हें पढ़ाने का लगभग सात साल का अनुभव है।';

/* ---------------------------------------------------------------- */
/* New courses: switch `open` to true when registration opens        */
/* ---------------------------------------------------------------- */

export interface Course {
  id: string;
  open: boolean;
  name: string;
  who: string;
  schedule: string;
  batch: string;
  price: string;
  dates: string[];
  points: string[];
}

export const courses: Course[] = [
  {
    id: 'spoken-english',
    open: false,
    name: 'Spoken English & Confidence Club',
    who: 'कक्षा 5–9',
    schedule: '8 हफ़्ते, 16 सेशन, शनिवार और रविवार, 75 मिनट',
    batch: '8 से 12 बच्चों का बैच',
    price: '₹1,400, दो किस्तों में',
    dates: ['मुफ़्त डेमो: रविवार 6 दिसंबर', 'पहला सेशन: शनिवार 19 दिसंबर'],
    points: [
      'अपना परिचय, रोज़ की बातचीत, कहानी सुनाना और फ़ोन पर बात करना',
      'शुरू, बीच और आख़िर में बोलने की रिकॉर्डिंग, जो सिर्फ़ उसी बच्चे के माता-पिता को मिलती है',
      'आख़िरी हफ़्ते माता-पिता के सामने दो मिनट का भाषण',
    ],
  },
  {
    id: 'computer-camp',
    open: false,
    name: 'Computer & AI Starter Camp',
    who: 'कक्षा 7–12 और 22 साल तक के युवा',
    schedule: 'दो वीकेंड, सुबह, कुल 10 घंटे',
    batch: '8 सीटें, दो बच्चों पर एक कंप्यूटर',
    price: '₹700',
    dates: ['पहला वीकेंड: 2 और 3 जनवरी', 'दूसरा वीकेंड: 9 और 10 जनवरी'],
    points: [
      'कंप्यूटर की बुनियादी बातें, फ़ाइल-फ़ोल्डर और टाइपिंग',
      'Excel या Google Sheets: फ़ॉर्मूले, मार्क्स शीट और चार्ट',
      'सुरक्षित इंटरनेट, OTP और UPI धोखाधड़ी से बचाव, और पढ़ाई में AI का सही इस्तेमाल',
      'आख़िरी दिन माता-पिता के सामने छोटा प्रोजेक्ट',
    ],
  },
];

/* ---------------------------------------------------------------- */
/* Parent policy: the same text as the sheet signed at admission     */
/* ---------------------------------------------------------------- */

export interface PolicyItem {
  topic: string;
  text: string;
  /** Shown only while at least one course is open. */
  coursesOnly?: boolean;
}

export const policy: PolicyItem[] = [
  {
    topic: 'उपस्थिति',
    text: 'क्लास सोमवार से शनिवार चलती हैं। बच्चा न आ पाए तो क्लास से पहले WhatsApp पर बता दें। महीने में तीन बार बिना बताए छुट्टी होने पर हम फ़ोन करेंगे।',
  },
  {
    topic: 'छूटी क्लास',
    text: 'उस दिन का काम हम भेज देते हैं। तीन दिन या उससे ज़्यादा बीमार रहने के बाद एक कैच-अप क्लास देते हैं।',
  },
  {
    topic: 'लंबी छुट्टी',
    text: 'बाहर जाने की बात पहले बता दें। पूरे महीने बाहर रहने पर सीट रखने के लिए आधी फ़ीस दें, वरना सीट इंतज़ार कर रहे बच्चे को दी जा सकती है।',
  },
  {
    topic: 'होमवर्क',
    text: 'होमवर्क रोज़ मिलता है। अधूरा होमवर्क घर जाने से पहले सेंटर पर पूरा होता है। हफ़्ते में तीन बार छूटने पर हम आपको बताते हैं।',
  },
  {
    topic: 'टेस्ट',
    text: 'हर महीने के पहले हफ़्ते टेस्ट होता है और तीन दिन में नतीजा मिलता है। उस दिन जो बच्चा नहीं आया, उसका टेस्ट उसी हफ़्ते दोबारा होता है।',
  },
  {
    topic: 'फ़ीस',
    text: 'फ़ीस हर महीने 10 तारीख़ तक, पहले से, UPI या नकद, हमेशा रसीद के साथ। फ़ीस में बदलाव एक महीना पहले बताया जाता है और अप्रैल से लागू होता है।',
  },
  {
    topic: 'कोर्स',
    text: 'कोर्स की फ़ीस एक साथ या दो किस्तों में। अगर हम कोर्स रद्द करें या आप बीच में छोड़ें, तो बचे हुए सेशन का पैसा 10 दिन में लौटा देते हैं।',
    coursesOnly: true,
  },
  {
    topic: 'व्यवहार',
    text: 'क्लास में फ़ोन बास्केट में रहते हैं और सबसे इज़्ज़त से बात होती है। किसी भी तरह की शारीरिक सज़ा या अपमान कभी नहीं।',
  },
  {
    topic: 'सुरक्षा',
    text: 'बच्चे बैच ख़त्म होने पर ही जाते हैं, या माता-पिता का मैसेज आने पर। कक्षा 1–5 का बच्चा क्लास शुरू होने के 15 मिनट बाद तक न पहुँचे तो हम आपको मैसेज करते हैं।',
  },
];
