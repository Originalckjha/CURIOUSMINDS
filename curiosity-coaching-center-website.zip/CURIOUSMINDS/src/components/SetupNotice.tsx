import { missingContactDetails } from '../lib/links';

function joinList(items: string[]) {
  if (items.length < 2) return items.join('');
  return `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

/** Owner-facing note. Shows only while required contact details are missing. */
export function SetupNotice() {
  const missing = missingContactDetails();
  if (missing.length === 0) return null;
  return (
    <div className="setup-note" role="note" lang="en">
      <strong>Not ready to go live:</strong> add your {joinList(missing)} in <code>src/content/site.ts</code>. This
      note disappears once they are filled in.
    </div>
  );
}
