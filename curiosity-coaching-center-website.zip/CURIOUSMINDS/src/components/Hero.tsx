import { MapPin, MessageCircle, Phone } from 'lucide-react';
import { site } from '../content/site';
import { directionsLink, messages, phoneLink, whatsappLink } from '../lib/links';
import { ReportSlip } from './ReportSlip';

export function Hero() {
  const tel = phoneLink();
  return (
    <section id="top" className="hero" aria-labelledby="hero-title">
      <div className="hero-text">
        <div className="hero-ruled">
          <h1 id="hero-title" className="hero-title">
            <span>हर महीने टेस्ट,</span> <span>हर महीने रिपोर्ट।</span>
          </h1>
          <p className="hero-motto" lang="en">
            {site.slogan.en}
          </p>
        </div>
        <p className="hero-intro">
          मंगोलपुरी, दिल्ली में कक्षा 1 से 10 की ट्यूशन। छोटे बैच, स्कूल का होमवर्क रोज़ चेक, हर महीने टेस्ट और
          माता-पिता को लिखित रिपोर्ट, ताकि आपको हमेशा पता रहे कि बच्चा कहाँ है।
        </p>
        <div id="hero-actions" className="hero-actions">
          <a className="btn btn-wa" href={whatsappLink(messages.general)} target="_blank" rel="noopener">
            <MessageCircle className="btn-icon" aria-hidden="true" />
            WhatsApp करें
          </a>
          {tel && (
            <a className="btn btn-line" href={tel}>
              <Phone className="btn-icon" aria-hidden="true" />
              कॉल करें
            </a>
          )}
          <a className="btn btn-line" href={directionsLink()} target="_blank" rel="noopener">
            <MapPin className="btn-icon" aria-hidden="true" />
            रास्ता देखें
          </a>
        </div>
        <p className="hero-note">
          नए बच्चों के लिए <a href="#level-check">मुफ़्त 30 मिनट का लेवल चेक</a>, फिर दो दिन ट्रायल क्लास।
        </p>
      </div>
      <ReportSlip />
    </section>
  );
}
