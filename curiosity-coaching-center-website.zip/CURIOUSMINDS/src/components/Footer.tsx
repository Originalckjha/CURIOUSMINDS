import { site } from '../content/site';
import { Monogram } from './Logo';

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-brand">
        <Monogram className="footer-mark" />
        <div>
          <p className="footer-name" lang="en">
            {site.name}
          </p>
          <p lang="en">{site.slogan.en}</p>
          <p>{site.slogan.hi}</p>
        </div>
      </div>

      <section className="privacy" aria-labelledby="privacy-title">
        <h2 id="privacy-title">आपकी जानकारी</h2>
        <p>
          यह वेबसाइट आपकी कोई जानकारी सेव नहीं करती और कोई ट्रैकिंग कुकी नहीं लगाती। WhatsApp या दाख़िले के समय आप जो
          जानकारी देते हैं (नाम, कक्षा, फ़ोन नंबर), वह सिर्फ़ जवाब देने, क्लास चलाने और रिपोर्ट भेजने के लिए है। उसे
          सिर्फ़ सेंटर के टीचर देखते हैं, और हम उसे किसी और को नहीं देते। किसी बच्चे की फ़ोटो, नाम या नंबर, माता-पिता
          की लिखित अनुमति के बिना कहीं नहीं लगाते।
        </p>
      </section>

      <p className="footer-copy">
        © <span suppressHydrationWarning>{new Date().getFullYear()}</span>{' '}
        <span lang="en">{site.name}</span>, {site.area.hi}
      </p>
    </footer>
  );
}
