import { MapPin, MessageCircle, Phone } from 'lucide-react';
import { Section } from '../components/Section';
import { site } from '../content/site';
import { directionsLink, messages, phoneLink, whatsappLink } from '../lib/links';

export function Location() {
  const { line, landmark, pincode } = site.address;
  const tel = phoneLink();

  return (
    <Section id="location" en="Location" hi="पता और समय">
      <address className="address">
        <strong lang="en">{site.name}</strong>
        {line ? (
          <>
            <span>{line}</span>
            {landmark && <span>{landmark}</span>}
            <span>
              {site.area.hi}
              {pincode ? ` ${pincode}` : ''}
            </span>
          </>
        ) : (
          <>
            <span>{site.area.hi}</span>
            <span>
              <a href={whatsappLink(messages.address)} target="_blank" rel="noopener">
                पूरा पता WhatsApp पर पूछें
              </a>
            </span>
          </>
        )}
      </address>

      {site.hours && (
        <p>
          <span className="label">समय:</span> {site.hours}
        </p>
      )}
      {site.phone && (
        <p>
          <span className="label">फ़ोन:</span>{' '}
          <a href={tel} className="nowrap">
            {site.phone}
          </a>
        </p>
      )}
      <p>आने से पहले एक मैसेज कर दें, ताकि हम आपके लिए समय रखें।</p>

      <div className="button-row">
        <a className="btn btn-wa" href={whatsappLink(messages.general)} target="_blank" rel="noopener">
          <MessageCircle className="btn-icon" aria-hidden="true" />
          WhatsApp करें
        </a>
        {tel && (
          <a className="btn btn-line" href={tel}>
            <Phone className="btn-icon" aria-hidden="true" />
            कॉल करें
          </a>
        )}
        <a className="btn btn-line" href={directionsLink()} target="_blank" rel="noopener">
          <MapPin className="btn-icon" aria-hidden="true" />
          रास्ता देखें
        </a>
      </div>
    </Section>
  );
}
