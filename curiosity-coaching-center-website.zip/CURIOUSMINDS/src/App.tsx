import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MobileBar } from './components/MobileBar';
import { SetupNotice } from './components/SetupNotice';
import { Batches } from './sections/Batches';
import { Courses } from './sections/Courses';
import { Fees } from './sections/Fees';
import { LevelCheck } from './sections/LevelCheck';
import { Location } from './sections/Location';
import { Policy } from './sections/Policy';
import { Reviews } from './sections/Reviews';
import { Teachers } from './sections/Teachers';
import { Teaching } from './sections/Teaching';

/**
 * One page, in the order of the growth plan's website outline:
 * top, how we teach, batches, fees, teachers, free level check,
 * new courses (only while open), parent policy, reviews, location, footer.
 */
export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">
        सीधे जानकारी पर जाएँ
      </a>
      <SetupNotice />
      <Header />
      <div className="page">
        <main id="main">
          <Hero />
          <Teaching />
          <Batches />
          <Fees />
          <Teachers />
          <LevelCheck />
          <Courses />
          <Policy />
          <Reviews />
          <Location />
        </main>
        <Footer />
      </div>
      <MobileBar />
    </>
  );
}
