/*
 * Marks drawn in the teacher's red pen. Red on this page means one thing:
 * something a teacher checked or marked. The `draw` variant animates the
 * stroke once on load (skipped when the visitor prefers reduced motion).
 */

interface MarkProps {
  className?: string;
  draw?: boolean;
}

export function Tick({ className = '', draw = false }: MarkProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" focusable="false">
      <path
        d="M3.4 12.9c2 1.5 3.6 3.3 5.2 5.6 3.1-5.5 7-10.2 12-14.4"
        pathLength={1}
        className={`pen-stroke${draw ? ' pen-draw' : ''}`}
      />
    </svg>
  );
}

export function Ring({ className = '', draw = false }: MarkProps) {
  return (
    <svg viewBox="0 0 120 60" className={className} aria-hidden="true" focusable="false" preserveAspectRatio="none">
      <path
        d="M80 6.8C53 3.2 18.5 8.6 9.8 25.4 2.3 40.6 30 55.2 62 54.6c27.4-.5 49.7-9.2 51.4-24.1C115 15.3 88.5 5.4 58 7.4 44.6 8.3 33.4 10.9 26.3 14.3"
        pathLength={1}
        className={`pen-stroke${draw ? ' pen-draw' : ''}`}
      />
    </svg>
  );
}
