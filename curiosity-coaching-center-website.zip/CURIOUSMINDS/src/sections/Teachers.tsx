import { Section } from '../components/Section';
import { teachers, teamLine } from '../content/site';
import { messages, whatsappLink } from '../lib/links';

export function Teachers() {
  return (
    <Section id="teachers" en="Teachers" hi="कौन पढ़ाता है">
      {teachers.length === 0 ? (
        <p className="lead">{teamLine}</p>
      ) : (
        <ul className="teacher-list">
          {teachers.map((teacher) => (
            <li key={teacher.name} className="teacher">
              {teacher.photo ? (
                <img
                  className="teacher-photo"
                  src={teacher.photo}
                  alt={teacher.name}
                  width={96}
                  height={96}
                  loading="lazy"
                  decoding="async"
                />
              ) : (
                <span className="teacher-initial" aria-hidden="true">
                  {teacher.name.trim().charAt(0)}
                </span>
              )}
              <div>
                <h3>{teacher.name}</h3>
                <dl className="teacher-facts">
                  {teacher.teaches && (
                    <div>
                      <dt>पढ़ाते हैं</dt>
                      <dd>{teacher.teaches}</dd>
                    </div>
                  )}
                  {teacher.qualification && (
                    <div>
                      <dt>पढ़ाई</dt>
                      <dd>{teacher.qualification}</dd>
                    </div>
                  )}
                  {teacher.experience && (
                    <div>
                      <dt>अनुभव</dt>
                      <dd>{teacher.experience}</dd>
                    </div>
                  )}
                </dl>
              </div>
            </li>
          ))}
        </ul>
      )}
      <p>
        मिलने के लिए सेंटर आइए।{' '}
        <a href={whatsappLink(messages.general)} target="_blank" rel="noopener">
          आने से पहले एक मैसेज कर दें
        </a>
        , ताकि हम आपके लिए समय रखें।
      </p>
    </Section>
  );
}
