import { Section } from '../components/Section';
import { messages, openCourses, whatsappLink } from '../lib/links';

/** Shown only while at least one course in content/site.ts has `open: true`. */
export function Courses() {
  const open = openCourses();
  if (open.length === 0) return null;

  return (
    <Section id="courses" en="New courses" hi="नए कोर्स">
      <p className="lead">पढ़ाई के साथ कंप्यूटर और अंग्रेज़ी बोलना भी।</p>
      <div className="course-list">
        {open.map((course) => (
          <article key={course.id} className="course">
            <h3 lang="en">{course.name}</h3>
            <dl className="course-facts">
              <div>
                <dt>किसके लिए</dt>
                <dd>{course.who}</dd>
              </div>
              <div>
                <dt>कब</dt>
                <dd>{course.schedule}</dd>
              </div>
              <div>
                <dt>बैच</dt>
                <dd>{course.batch}</dd>
              </div>
              <div>
                <dt>फ़ीस</dt>
                <dd>{course.price}</dd>
              </div>
            </dl>
            <ul className="plain-list">
              {course.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
            {course.dates.map((date) => (
              <p key={date} className="course-date">
                {date}
              </p>
            ))}
            <a
              className="btn btn-line"
              href={whatsappLink(messages.course(course.name))}
              target="_blank"
              rel="noopener"
            >
              रुचि बताएँ
            </a>
          </article>
        ))}
      </div>
    </Section>
  );
}
