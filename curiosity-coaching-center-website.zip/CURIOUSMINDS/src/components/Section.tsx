import type { ReactNode } from 'react';

interface SectionProps {
  id: string;
  /** English heading, written in the notebook's margin on wide screens. */
  en: string;
  /** Hindi heading under it. */
  hi: string;
  children: ReactNode;
}

export function Section({ id, en, hi, children }: SectionProps) {
  return (
    <section id={id} className="section" aria-labelledby={`${id}-title`}>
      <div className="section-head">
        <h2 id={`${id}-title`}>
          <span className="section-en" lang="en">
            {en}
          </span>
          <span className="section-hi">{hi}</span>
        </h2>
      </div>
      <div className="section-body">{children}</div>
    </section>
  );
}
