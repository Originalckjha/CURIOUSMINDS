import { courses, site } from '../content/site';

/**
 * Every WhatsApp message sent from the website ends with this code, so an
 * enquiry from the site can be logged with "Website" as its source.
 */
export const WEBSITE_CODE = '(WEB)';

export const messages = {
  general: 'नमस्ते, क्लास की जानकारी चाहिए।',
  levelCheck: 'नमस्ते, बच्चे का मुफ़्त लेवल चेक बुक करना है।',
  timings: 'नमस्ते, बैच का समय बताइए।',
  fees: 'नमस्ते, फ़ीस की जानकारी चाहिए।',
  morningBatch: 'नमस्ते, सुबह के बैच में रुचि है।',
  address: 'नमस्ते, सेंटर आना है, पूरा पता बताइए।',
  course: (name: string) => `नमस्ते, ${name} में रुचि है।`,
};

const digitsOf = (value: string) => value.replace(/\D/g, '');

export function whatsappLink(message: string): string {
  const separator = message.includes('\n') ? '\n' : ' ';
  const text = encodeURIComponent(`${message}${separator}${WEBSITE_CODE}`);
  const number = digitsOf(site.whatsapp);
  return number ? `https://wa.me/${number}?text=${text}` : `https://wa.me/?text=${text}`;
}

/** tel: link in international form, or '' when no phone number is set. */
export function phoneLink(): string {
  let number = digitsOf(site.phone);
  if (!number) return '';
  if (number.length === 10) number = `91${number}`;
  else if (number.startsWith('0')) number = `91${number.replace(/^0+/, '')}`;
  return `tel:+${number}`;
}

const mapsSearch = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  `${site.name}, ${site.area.en}`,
)}`;

export const directionsLink = (): string => site.mapsUrl || mapsSearch;
export const reviewsLink = (): string => site.reviewsUrl || site.mapsUrl || mapsSearch;

export const openCourses = () => courses.filter((course) => course.open);

/** Contact details the page cannot work without. Listed in the setup note until filled. */
export function missingContactDetails(): string[] {
  const missing: string[] = [];
  if (!digitsOf(site.whatsapp)) missing.push('WhatsApp number');
  if (!digitsOf(site.phone)) missing.push('phone number');
  if (!site.address.line) missing.push('address');
  if (!site.mapsUrl) missing.push('Google Maps link');
  return missing;
}
