/**
 * Tailwind is kept for its reset (preflight). The page's own styles are
 * plain CSS in src/index.css, where the colours are defined once as variables.
 * @type {import('tailwindcss').Config}
 */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
};
