import { useId, useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { Section } from '../components/Section';
import { levelCheck } from '../content/site';
import { messages, whatsappLink } from '../lib/links';

const CLASSES = Array.from({ length: 10 }, (_, i) => `कक्षा ${i + 1}`);
const SHIFTS = ['सुबह की शिफ़्ट', 'दोपहर की शिफ़्ट', 'प्राइवेट स्कूल'];

function bookingMessage(childClass: string, shift: string, parent: string, referredBy: string) {
  const lines = [messages.levelCheck];
  if (childClass) lines.push(`बच्चे की कक्षा: ${childClass}`);
  if (shift) lines.push(`स्कूल: ${shift}`);
  if (parent.trim()) lines.push(`मेरा नाम: ${parent.trim()}`);
  if (referredBy.trim()) lines.push(`हमें बताया: ${referredBy.trim()}`);
  return lines.join('\n');
}

function BookingForm() {
  const id = useId();
  const [childClass, setChildClass] = useState('');
  const [shift, setShift] = useState('');
  const [parent, setParent] = useState('');
  const [referredBy, setReferredBy] = useState('');
  const href = whatsappLink(bookingMessage(childClass, shift, parent, referredBy));

  return (
    <div className="booking">
      <h3 className="booking-title">लेवल चेक बुक करें</h3>
      <div className="booking-fields">
        <div className="field">
          <label htmlFor={`${id}-class`}>बच्चे की कक्षा</label>
          <select id={`${id}-class`} value={childClass} onChange={(e) => setChildClass(e.target.value)}>
            <option value="">चुनिए</option>
            {CLASSES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor={`${id}-shift`}>स्कूल की शिफ़्ट</label>
          <select id={`${id}-shift`} value={shift} onChange={(e) => setShift(e.target.value)}>
            <option value="">चुनिए</option>
            {SHIFTS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor={`${id}-parent`}>
            आपका नाम <span className="optional">(चाहें तो)</span>
          </label>
          <input
            id={`${id}-parent`}
            type="text"
            autoComplete="name"
            value={parent}
            onChange={(e) => setParent(e.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor={`${id}-ref`}>
            किसी ने हमारे बारे में बताया? उनका नाम <span className="optional">(चाहें तो)</span>
          </label>
          <input
            id={`${id}-ref`}
            type="text"
            autoComplete="off"
            value={referredBy}
            onChange={(e) => setReferredBy(e.target.value)}
          />
        </div>
      </div>
      <a className="btn btn-wa booking-send" href={href} target="_blank" rel="noopener">
        <MessageCircle className="btn-icon" aria-hidden="true" />
        WhatsApp पर बुक करें
      </a>
      <p className="booking-privacy">
        यह फ़ॉर्म कुछ भी सेव नहीं करता। बटन दबाने पर WhatsApp में आपका मैसेज तैयार हो जाएगा, भेजना आपके हाथ में है।
      </p>
    </div>
  );
}

export function LevelCheck() {
  const saturday = levelCheck.saturdayTime ? `हर शनिवार ${levelCheck.saturdayTime}` : 'हर शनिवार';
  const when = `${saturday}, या किसी बैच से पहले।`;
  return (
    <Section id="level-check" en="Free level check" hi="मुफ़्त लेवल चेक">
      <p className="lead">
        नए बच्चों के लिए, बिना किसी फ़ीस के। आप दाख़िला लें या न लें, नतीजा लिखकर आपको मिलेगा।
      </p>
      <ol className="steps">
        <li>
          <h3>WhatsApp पर दिन तय कीजिए</h3>
          <p>{when}</p>
        </li>
        <li>
          <h3>30 मिनट का टेस्ट</h3>
          <p>बच्चे की कक्षा के हिसाब से मैथ्स और इंग्लिश।</p>
        </li>
        <li>
          <h3>उसी दिन लिखित नतीजा</h3>
          <p>बच्चे की तीन ताक़तें, तीन कमियाँ और अगले चार हफ़्ते का प्लान।</p>
        </li>
        <li>
          <h3>दो दिन ट्रायल क्लास</h3>
          <p>उसके बाद आप तय कीजिए।</p>
        </li>
      </ol>
      <BookingForm />
    </Section>
  );
}
