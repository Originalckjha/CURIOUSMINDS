import { Section } from '../components/Section';
import { policy, site } from '../content/site';
import { openCourses } from '../lib/links';

export function Policy() {
  const coursesOpen = openCourses().length > 0;
  const items = policy.filter((item) => !item.coursesOnly || coursesOpen);
  if (site.replyHours) {
    items.push({ topic: 'जवाब का समय', text: `हम ${site.replyHours} के बीच मैसेज का जवाब देते हैं।` });
  }

  return (
    <Section id="policy" en="Parent policy" hi="पेरेंट पॉलिसी">
      <p className="lead">दाख़िले के समय यही पन्ना दिया जाता है, और उस पर दोनों तरफ़ से साइन होते हैं।</p>
      <dl className="policy">
        {items.map((item) => (
          <div key={item.topic} className="policy-row">
            <dt>{item.topic}</dt>
            <dd>{item.text}</dd>
          </div>
        ))}
      </dl>
    </Section>
  );
}
