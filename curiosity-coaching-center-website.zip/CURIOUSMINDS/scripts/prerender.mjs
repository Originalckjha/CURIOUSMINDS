/*
 * Runs after `vite build`: renders the page to plain HTML so it shows up
 * instantly on slow phones and Google reads the full text, then writes the
 * 404 page, robots.txt and (when the site address is known) sitemap.xml.
 */
import { readFile, readdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const ssrDir = path.join(root, 'dist-ssr');

const ssr = await import(pathToFileURL(path.join(ssrDir, 'entry-server.js')).href);

function siteOrigin() {
  const fromVercel = process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : '';
  const origin = process.env.SITE_URL || ssr.site.siteUrl || fromVercel;
  return origin.replace(/\/+$/, '');
}

const origin = siteOrigin();
const indexPath = path.join(dist, 'index.html');
const template = await readFile(indexPath, 'utf8');

if (!template.includes('<!--app-->') || !template.includes('<!--head-->')) {
  throw new Error('index.html is missing the <!--app--> or <!--head--> placeholder.');
}

// Preload the two Hindi font files the first screen needs.
const assets = await readdir(path.join(dist, 'assets'));
const preloads = assets
  .filter((file) => /^mukta-devanagari-(400|700)-normal-.+\.woff2$/.test(file))
  .map((file) => `<link rel="preload" href="/assets/${file}" as="font" type="font/woff2" crossorigin />`);

const html = template
  .replace('<!--head-->', [...preloads, ssr.head(origin)].join('\n    '))
  .replace('<!--app-->', ssr.render());

await writeFile(indexPath, html);

await writeFile(
  path.join(dist, '404.html'),
  `<!doctype html>
<html lang="hi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="robots" content="noindex" />
    <title>पेज नहीं मिला | Curiosity Coaching Center</title>
    <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
    <style>
      body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #fffefb; color: #1c2757;
        font-family: 'Nirmala UI', 'Noto Sans Devanagari', system-ui, sans-serif; font-size: 1.125rem; line-height: 1.6; }
      main { padding: 2rem 1.5rem; max-width: 30rem; }
      img { height: 3rem; }
      a { color: inherit; font-weight: 700; }
    </style>
  </head>
  <body>
    <main>
      <img src="/favicon.svg" alt="" />
      <p>यह पेज नहीं मिला।</p>
      <p><a href="/">Curiosity Coaching Center का पेज खोलें</a></p>
    </main>
  </body>
</html>
`,
);

await writeFile(
  path.join(dist, 'robots.txt'),
  `User-agent: *\nAllow: /\n${origin ? `\nSitemap: ${origin}/sitemap.xml\n` : ''}`,
);

if (origin) {
  await writeFile(
    path.join(dist, 'sitemap.xml'),
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${origin}/</loc></url>\n</urlset>\n`,
  );
}

await rm(ssrDir, { recursive: true, force: true });

const todo = ssr.setupReport(origin);
console.log(`\nPrerendered dist/index.html${origin ? ` for ${origin}` : ''}.`);
if (todo.length) {
  console.log('Still to fill in src/content/site.ts:');
  for (const item of todo) console.log(`  - ${item}`);
}
